const express = require('express');
const path = require('path');
const app = express();

app.use('/public', express.static(path.join(__dirname, 'public'))); 

app.get('/', (req, res) => {
  res.send(`
    <h1>Strona główna</h1>
    <p>Otwieram okno chłonąc zew morza,rześki wiatr, wielki świat, wodne bezdroża to tylko mały ja kontra ogrom przestworza i młodzi chłopcy, co pakują sobie biel w nozdrza</p>
  `);
});

app.get('/kontakt', (req, res) => {
  res.send(`
    <h1>Kontakt</h1>
    <form>
      <label for="name">Imię:
      <input type="text" id="name" name="name"><br><br>
      </label>

      <label for="email">Adres e-mail:
      <input type="email" id="email" name="email"><br><br>
      </label>

      <label for="album">Temat:

      <select id="album" name="album">
        <option value="europa">Europa</option>
        <option value="jarmark">Jarmark</option>
      </select>

      </label>
      
      <br><br>

      <label for="message">Treść wiadomości:<br>
      <textarea id="message" name="message" rows="4" cols="50"></textarea><br><br>
      </label>

      <input type="submit" value="Wyślij">
    </form>
    <script src="/public/js/form.js"></script>
  `);
});

app.listen(3000, () => {
  console.log('Serwer uruchomiony na porcie 3000');
});
